#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QSqlRecord>
#include <QSqlField>
#include <QModelIndex>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 设置窗口标题
    this->setWindowTitle("学生信息管理系统");

    connectDatabase();
    fetchSessionId();
    setupModel();
}

MainWindow::~MainWindow()
{
    if (db.isOpen()) {
        db.close();
    }
    delete ui;
}

void MainWindow::connectDatabase()
{
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setUserName("root");
    db.setPassword("12345678");
    db.setDatabaseName("studentdb");

    if (!db.open()) {
        QMessageBox::critical(this, "数据库错误",
                             "无法连接到数据库: " + db.lastError().text() +
                             "\n请检查:\n1. MySQL服务器是否运行\n2. 数据库和用户是否已创建\n3. MySQL驱动是否安装");
    } else {
        ui->statusbar->showMessage("数据库连接成功", 3000);
    }
}

void MainWindow::fetchSessionId()
{
    QSqlQuery query(db);
    if (query.exec("SELECT CONNECTION_ID()") && query.next()) {
        currentSid = query.value(0).toInt();
        ui->statusbar->showMessage("当前会话 SID: " + QString::number(currentSid));
    } else {
        currentSid = -1;
        ui->statusbar->showMessage("无法获取会话ID: " + query.lastError().text());
    }
}

void MainWindow::setupModel()
{
    model = new QSqlTableModel(this, db);
    model->setTable("student");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    refreshTable();

    model->setHeaderData(0, Qt::Horizontal, "ID");
    model->setHeaderData(1, Qt::Horizontal, "姓名");
    model->setHeaderData(2, Qt::Horizontal, "年龄");
    model->setHeaderData(3, Qt::Horizontal, "专业");
    model->setHeaderData(4, Qt::Horizontal, "SID");

    ui->tableView->setModel(model);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
}

void MainWindow::refreshTable()
{
    model->setFilter("");
    if (!model->select()) {
        QMessageBox::warning(this, "查询错误", "无法刷新数据: " + model->lastError().text());
    }
}

void MainWindow::on_addButton_clicked()
{
    QString name = ui->nameEdit->text().trimmed();
    QString ageStr = ui->ageEdit->text().trimmed();
    QString major = ui->majorEdit->text().trimmed();

    if (name.isEmpty() || ageStr.isEmpty() || major.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写所有字段");
        return;
    }

    bool ok;
    int age = ageStr.toInt(&ok);
    if (!ok || age <= 0 || age > 150) {
        QMessageBox::warning(this, "输入错误", "年龄必须是1-150之间的整数");
        return;
    }

    QSqlRecord record = model->record();
    record.setValue("name", name);
    record.setValue("age", age);
    record.setValue("major", major);
    record.setValue("sid", currentSid);

    if (model->insertRecord(-1, record)) {
        if (model->submitAll()) {
            ui->nameEdit->clear();
            ui->ageEdit->clear();
            ui->majorEdit->clear();
            refreshTable();
            ui->statusbar->showMessage("添加成功", 3000);
        } else {
            QMessageBox::warning(this, "提交失败", model->lastError().text());
            model->revertAll();
        }
    } else {
        QMessageBox::warning(this, "插入失败", model->lastError().text());
    }
}

void MainWindow::on_deleteButton_clicked()
{
    QModelIndexList indexes = ui->tableView->selectionModel()->selectedRows();
    if (indexes.isEmpty()) {
        QMessageBox::information(this, "提示", "请先选择要删除的行");
        return;
    }

    int row = indexes.first().row();
    QString name = model->data(model->index(row, 1)).toString();

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认删除",
                                 "确定要删除学生 " + name + " 吗？",
                                 QMessageBox::Yes|QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        model->removeRow(row);
        if (model->submitAll()) {
            refreshTable();
            ui->statusbar->showMessage("删除成功", 3000);
        } else {
            QMessageBox::warning(this, "删除失败", model->lastError().text());
            model->revertAll();
        }
    }
}

void MainWindow::on_updateButton_clicked()
{
    QModelIndexList indexes = ui->tableView->selectionModel()->selectedRows();
    if (indexes.isEmpty()) {
        QMessageBox::information(this, "提示", "请先选择要修改的行");
        return;
    }

    int row = indexes.first().row();

    QString name = ui->nameEdit->text().trimmed();
    QString ageStr = ui->ageEdit->text().trimmed();
    QString major = ui->majorEdit->text().trimmed();

    if (name.isEmpty() || ageStr.isEmpty() || major.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写所有字段");
        return;
    }

    bool ok;
    int age = ageStr.toInt(&ok);
    if (!ok || age <= 0 || age > 150) {
        QMessageBox::warning(this, "输入错误", "年龄必须是1-150之间的整数");
        return;
    }

    model->setData(model->index(row, 1), name);
    model->setData(model->index(row, 2), age);
    model->setData(model->index(row, 3), major);

    if (model->submitAll()) {
        refreshTable();
        ui->statusbar->showMessage("修改成功", 3000);
    } else {
        QMessageBox::warning(this, "修改失败", model->lastError().text());
        model->revertAll();
    }
}

void MainWindow::on_refreshButton_clicked()
{
    refreshTable();
    ui->statusbar->showMessage("数据已刷新", 3000);
}

void MainWindow::on_searchSidButton_clicked()
{
    QString sid = ui->sidEdit->text().trimmed();
    if (sid.isEmpty()) {
        QMessageBox::information(this, "提示", "请输入要查询的会话 SID");
        return;
    }

    bool ok;
    int sidValue = sid.toInt(&ok);
    if (!ok || sidValue <= 0) {
        QMessageBox::warning(this, "输入错误", "SID 必须是正整数");
        return;
    }

    model->setFilter(QString("sid = %1").arg(sidValue));
    if (!model->select()) {
        QMessageBox::warning(this, "查询错误", model->lastError().text());
        return;
    }

    if (model->rowCount() == 0) {
        QMessageBox::information(this, "查询结果", "没有找到对应的记录");
        refreshTable();
    } else {
        ui->statusbar->showMessage(QString("找到 %1 条记录").arg(model->rowCount()), 3000);
    }
}
