#include "notepad.h"
#include <QApplication>

Notepad::Notepad(QWidget *parent)
    : QMainWindow(parent)
{
    // 创建文本编辑区域
    textEdit = new QTextEdit(this);
    setCentralWidget(textEdit);

    // 创建动作和菜单
    createActions();
    createMenus();
    createToolBars();

    // 设置窗口属性
    setWindowTitle("Notepad文本编辑器");
    setGeometry(100, 100, 800, 600);
    currentFile = "";
}

Notepad::~Notepad() {}

void Notepad::createActions()
{
    // 文件操作
    newAction = new QAction("新建", this);
    newAction->setShortcut(QKeySequence::New);
    connect(newAction, &QAction::triggered, this, &Notepad::newFile);

    openAction = new QAction("打开", this);
    openAction->setShortcut(QKeySequence::Open);
    connect(openAction, &QAction::triggered, this, &Notepad::openFile);

    saveAction = new QAction("保存", this);
    saveAction->setShortcut(QKeySequence::Save);
    connect(saveAction, &QAction::triggered, this, &Notepad::saveFile);

    saveAsAction = new QAction("另存为", this);
    saveAsAction->setShortcut(QKeySequence::SaveAs);
    connect(saveAsAction, &QAction::triggered, this, &Notepad::saveAsFile);

    exitAction = new QAction("退出", this);
    exitAction->setShortcut(QKeySequence::Quit);
    connect(exitAction, &QAction::triggered, this, &Notepad::exitApp);

    // 编辑操作
    cutAction = new QAction("剪切", this);
    cutAction->setShortcut(QKeySequence::Cut);
    connect(cutAction, &QAction::triggered, this, &Notepad::cutText);

    copyAction = new QAction("复制", this);
    copyAction->setShortcut(QKeySequence::Copy);
    connect(copyAction, &QAction::triggered, this, &Notepad::copyText);

    pasteAction = new QAction("粘贴", this);
    pasteAction->setShortcut(QKeySequence::Paste);
    connect(pasteAction, &QAction::triggered, this, &Notepad::pasteText);

    undoAction = new QAction("撤销", this);
    undoAction->setShortcut(QKeySequence::Undo);
    connect(undoAction, &QAction::triggered, this, &Notepad::undoText);

    redoAction = new QAction("重做", this);
    redoAction->setShortcut(QKeySequence::Redo);
    connect(redoAction, &QAction::triggered, this, &Notepad::redoText);

    // 格式操作
    fontAction = new QAction("字体", this);
    connect(fontAction, &QAction::triggered, this, &Notepad::selectFont);

    colorAction = new QAction("颜色", this);
    connect(colorAction, &QAction::triggered, this, &Notepad::selectFontColor);

    // 帮助操作
    aboutAction = new QAction("关于", this);
    connect(aboutAction, &QAction::triggered, this, &Notepad::about);
}

void Notepad::createMenus()
{
    // 文件菜单
    fileMenu = menuBar()->addMenu("文件");
    fileMenu->addAction(newAction);
    fileMenu->addAction(openAction);
    fileMenu->addAction(saveAction);
    fileMenu->addAction(saveAsAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    // 编辑菜单
    editMenu = menuBar()->addMenu("编辑");
    editMenu->addAction(cutAction);
    editMenu->addAction(copyAction);
    editMenu->addAction(pasteAction);
    editMenu->addAction(undoAction);
    editMenu->addAction(redoAction);

    // 格式菜单
    formatMenu = menuBar()->addMenu("格式");
    formatMenu->addAction(fontAction);
    formatMenu->addAction(colorAction);

    // 帮助菜单
    helpMenu = menuBar()->addMenu("帮助");
    helpMenu->addAction(aboutAction);
}

void Notepad::createToolBars()
{
    // 文件工具栏
    fileToolBar = addToolBar("文件");
    fileToolBar->addAction(newAction);
    fileToolBar->addAction(openAction);
    fileToolBar->addAction(saveAction);

    // 编辑工具栏
    editToolBar = addToolBar("编辑");
    editToolBar->addAction(cutAction);
    editToolBar->addAction(copyAction);
    editToolBar->addAction(pasteAction);
    editToolBar->addAction(undoAction);
    editToolBar->addAction(redoAction);
}

void Notepad::newFile()
{
    if (maybeSave()) {
        textEdit->clear();
        currentFile = "";
        setWindowTitle("Notepad文本编辑器 - 新文件");
    }
}

void Notepad::openFile()
{
    if (maybeSave()) {
        QString fileName = QFileDialog::getOpenFileName(this, "打开文件");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                textEdit->setPlainText(file.readAll());
                file.close();
                currentFile = fileName;
                setWindowTitle("Notepad文本编辑器 - " + fileName);
            }
        }
    }
}

void Notepad::saveFile()
{
    if (currentFile.isEmpty()) {
        saveAsFile();
    } else {
        QFile file(currentFile);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            file.write(textEdit->toPlainText().toUtf8());
            file.close();
        }
    }
}

void Notepad::saveAsFile()
{
    QString fileName = QFileDialog::getSaveFileName(this, "另存为");
    if (!fileName.isEmpty()) {
        currentFile = fileName;
        saveFile();
        setWindowTitle("Notepad文本编辑器 - " + fileName);
    }
}

void Notepad::exitApp()
{
    close();
}

void Notepad::cutText()
{
    textEdit->cut();
}

void Notepad::copyText()
{
    textEdit->copy();
}

void Notepad::pasteText()
{
    textEdit->paste();
}

void Notepad::undoText()
{
    textEdit->undo();
}

void Notepad::redoText()
{
    textEdit->redo();
}

void Notepad::selectFont()
{
    bool ok;
    QFont font = QFontDialog::getFont(&ok, textEdit->font(), this);
    if (ok) {
        textEdit->setFont(font);
    }
}

void Notepad::selectFontColor()
{
    QColor color = QColorDialog::getColor(textEdit->textColor(), this);
    if (color.isValid()) {
        textEdit->setTextColor(color);
    }
}

void Notepad::about()
{
    QMessageBox::about(this, "关于 Notepad",
        "<h2>Notepad文本编辑器</h2>"
        "<p>一个简单的文本编辑器实现</p>"
        "<p>支持基本的文本编辑功能：</p>"
        "<ul>"
        "<li>新建、打开、保存文件</li>"
        "<li>剪切、复制、粘贴</li>"
        "<li>撤销、重做</li>"
        "<li>字体和颜色设置</li>"
        "</ul>");
}

bool Notepad::maybeSave()
{
    if (textEdit->document()->isModified()) {
        QMessageBox::StandardButton ret;
        ret = QMessageBox::warning(this, "Notepad",
                     "文档已被修改，是否保存更改？",
                     QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save) {
            saveFile();
            return true;
        } else if (ret == QMessageBox::Cancel) {
            return false;
        }
    }
    return true;
}

void Notepad::closeEvent(QCloseEvent *event)
{
    if (maybeSave()) {
        event->accept();
    } else {
        event->ignore();
    }
}
