#ifndef NOTEPAD_H
#define NOTEPAD_H

#include <QMainWindow>
#include <QTextEdit>
#include <QFileDialog>
#include <QMessageBox>
#include <QFontDialog>
#include <QColorDialog>
#include <QCloseEvent>

// 添加以下头文件包含
#include <QAction>
#include <QMenu>
#include <QToolBar>
#include <QMenuBar>
#include <QKeySequence>
#include <QFile>
#include <QIODevice>

class Notepad : public QMainWindow
{
    Q_OBJECT

public:
    Notepad(QWidget *parent = nullptr);
    ~Notepad();

private slots:
    void newFile();
    void openFile();
    void saveFile();
    void saveAsFile();
    void exitApp();
    void cutText();
    void copyText();
    void pasteText();
    void undoText();
    void redoText();
    void selectFont();
    void selectFontColor();
    void about();

private:
    void createActions();
    void createMenus();
    void createToolBars();
    void closeEvent(QCloseEvent *event);
    bool maybeSave();

    QTextEdit *textEdit;
    QString currentFile;

    // 菜单
    QMenu *fileMenu;
    QMenu *editMenu;
    QMenu *formatMenu;
    QMenu *helpMenu;

    // 工具栏
    QToolBar *fileToolBar;
    QToolBar *editToolBar;

    // 动作
    QAction *newAction;
    QAction *openAction;
    QAction *saveAction;
    QAction *saveAsAction;
    QAction *exitAction;
    QAction *cutAction;
    QAction *copyAction;
    QAction *pasteAction;
    QAction *undoAction;
    QAction *redoAction;
    QAction *fontAction;
    QAction *colorAction;
    QAction *aboutAction;
};

#endif // NOTEPAD_H
