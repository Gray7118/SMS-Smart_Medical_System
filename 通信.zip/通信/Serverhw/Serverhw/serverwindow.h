#ifndef SERVERWINDOW_H
#define SERVERWINDOW_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QList>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QMessageBox>
#include <QNetworkInterface>

// 移除命名空间声明，直接定义 Ui 类
class ServerWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ServerWindow(QWidget *parent = nullptr);
    ~ServerWindow();

private slots:
    void onNewConnection();
    void onSocketReadyRead();
    void onSocketDisconnected();
    void on_btnStart_clicked();
    void on_btnSend_clicked();

private:
    void updateState();

    // 直接声明控件指针，不使用 Ui 命名空间
    QTcpServer *tcpServer;
    QList<QTcpSocket*> clientSockets;

    // UI 控件
    QVBoxLayout *mainLayout;
    QHBoxLayout *portLayout;
    QLabel *labelPort;
    QLineEdit *lineEditPort;
    QPushButton *btnStart;
    QTextEdit *textEditRecv;
    QTextEdit *textEditSend;
    QPushButton *btnSend;
};

#endif // SERVERWINDOW_H
