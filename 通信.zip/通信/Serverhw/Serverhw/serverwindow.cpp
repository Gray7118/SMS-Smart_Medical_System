#include "serverwindow.h"

ServerWindow::ServerWindow(QWidget *parent) :
    QWidget(parent),
    tcpServer(new QTcpServer(this))
{
    // 设置窗口和控件
    setWindowTitle("TCP Server - Serverhw4");
    resize(600, 400);

    // 创建布局和控件
    mainLayout = new QVBoxLayout(this);

    labelPort = new QLabel("端口:");
    lineEditPort = new QLineEdit("8888");
    btnStart = new QPushButton("启动服务器");
    textEditRecv = new QTextEdit();
    textEditSend = new QTextEdit();
    btnSend = new QPushButton("发送");

    portLayout = new QHBoxLayout();
    portLayout->addWidget(labelPort);
    portLayout->addWidget(lineEditPort);
    portLayout->addWidget(btnStart);

    mainLayout->addLayout(portLayout);
    mainLayout->addWidget(new QLabel("接收消息:"));
    mainLayout->addWidget(textEditRecv);
    mainLayout->addWidget(new QLabel("发送消息:"));
    mainLayout->addWidget(textEditSend);
    mainLayout->addWidget(btnSend);

    // 连接信号槽
    connect(btnStart, &QPushButton::clicked, this, &ServerWindow::on_btnStart_clicked);
    connect(btnSend, &QPushButton::clicked, this, &ServerWindow::on_btnSend_clicked);
    connect(tcpServer, &QTcpServer::newConnection, this, &ServerWindow::onNewConnection);

    updateState();
}

ServerWindow::~ServerWindow()
{
    // 不再需要删除 ui 对象，因为所有控件都是此窗口的子对象
    // Qt 会自动处理它们的销毁
}

void ServerWindow::updateState()
{
    if (tcpServer->isListening()) {
        btnStart->setText("停止服务器");
    } else {
        btnStart->setText("启动服务器");
    }
}

void ServerWindow::on_btnStart_clicked()
{
    if (tcpServer->isListening()) {
        tcpServer->close();
        for (QTcpSocket *socket : clientSockets) {
            socket->close();
            socket->deleteLater();
        }
        clientSockets.clear();
        textEditRecv->append("服务器已停止");
    } else {
        bool ok;
        quint16 port = lineEditPort->text().toUShort(&ok);
        if (!ok || port == 0) {
            QMessageBox::warning(this, "错误", "无效的端口号!");
            return;
        }
        if (!tcpServer->listen(QHostAddress::Any, port)) {
            QMessageBox::critical(this, "错误", QString("无法启动服务器: %1").arg(tcpServer->errorString()));
            return;
        }
        textEditRecv->append(QString("服务器已在端口 %1 启动").arg(port));
    }
    updateState();
}

void ServerWindow::onNewConnection()
{
    while (tcpServer->hasPendingConnections()) {
        QTcpSocket *clientSocket = tcpServer->nextPendingConnection();
        clientSockets.append(clientSocket);

        textEditRecv->append(QString("客户端连接: %1:%2")
                                  .arg(clientSocket->peerAddress().toString())
                                  .arg(clientSocket->peerPort()));

        connect(clientSocket, &QTcpSocket::readyRead, this, &ServerWindow::onSocketReadyRead);
        connect(clientSocket, &QTcpSocket::disconnected, this, &ServerWindow::onSocketDisconnected);
    }
}

void ServerWindow::onSocketReadyRead()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket*>(sender());
    if (socket) {
        QByteArray data = socket->readAll();
        QString message = QString::fromUtf8(data);
        textEditRecv->append(QString("[客户端]: %1").arg(message));
    }
}

void ServerWindow::onSocketDisconnected()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket*>(sender());
    if (socket) {
        textEditRecv->append(QString("客户端断开连接: %1:%2")
                                  .arg(socket->peerAddress().toString())
                                  .arg(socket->peerPort()));
        clientSockets.removeOne(socket);
        socket->deleteLater();
    }
}

void ServerWindow::on_btnSend_clicked()
{
    QString message = textEditSend->toPlainText().trimmed();
    if (message.isEmpty() || clientSockets.isEmpty()) {
        return;
    }

    for (QTcpSocket *socket : clientSockets) {
        if (socket->state() == QAbstractSocket::ConnectedState) {
            socket->write(message.toUtf8());
        }
    }
    textEditSend->clear();
    textEditRecv->append(QString("[服务器]: %1").arg(message));
}
