#include "clientwindow.h"

ClientWindow::ClientWindow(QWidget *parent) :
    QWidget(parent),
    tcpSocket(new QTcpSocket(this))
{
    // 设置窗口和控件
    setWindowTitle("TCP Client - Clienthw4");
    resize(600, 400);

    // 设置窗口背景颜色和圆角
    setStyleSheet("QWidget {"
                 "background-color: #f0f8ff;"  // 浅蓝色背景
                 "border-radius: 10px;"
                 "}");

    // 创建布局和控件
    mainLayout = new QVBoxLayout(this);

    labelIP = new QLabel("服务器IP:");
    comboBoxIP = new QComboBox();
    labelPort = new QLabel("端口:");
    lineEditPort = new QLineEdit("8888");
    btnConnect = new QPushButton("连接");
    textEditRecv = new QTextEdit();
    textEditSend = new QTextEdit();
    btnSend = new QPushButton("发送");

    connectLayout = new QHBoxLayout();
    connectLayout->addWidget(labelIP);
    connectLayout->addWidget(comboBoxIP);
    connectLayout->addWidget(labelPort);
    connectLayout->addWidget(lineEditPort);
    connectLayout->addWidget(btnConnect);

    mainLayout->addLayout(connectLayout);
    mainLayout->addWidget(new QLabel("接收消息:"));
    mainLayout->addWidget(textEditRecv);
    mainLayout->addWidget(new QLabel("发送消息:"));
    mainLayout->addWidget(textEditSend);
    mainLayout->addWidget(btnSend);

    // 连接信号槽 - 使用正确的语法
    connect(btnConnect, &QPushButton::clicked, this, &ClientWindow::on_btnConnect_clicked);
    connect(btnSend, &QPushButton::clicked, this, &ClientWindow::on_btnSend_clicked);
    connect(tcpSocket, &QTcpSocket::connected, this, &ClientWindow::onConnected);
    connect(tcpSocket, &QTcpSocket::disconnected, this, &ClientWindow::onDisconnected);
    connect(tcpSocket, &QTcpSocket::readyRead, this, &ClientWindow::onReadyRead);
    connect(tcpSocket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::error),
            this, &ClientWindow::onErrorOccurred);

    // 填充IP地址
    populateIPs();

    // 更新UI状态
    btnConnect->setEnabled(true);
    btnSend->setEnabled(false);
}

ClientWindow::~ClientWindow()
{
    // 不再需要删除 ui 对象，因为所有控件都是此窗口的子对象
    // Qt 会自动处理它们的销毁
}

void ClientWindow::populateIPs()
{
    comboBoxIP->clear();
    // 获取所有可用IP地址
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    for (const QHostAddress &address : ipAddressesList) {
        // 过滤IPv4地址（非本地回环）
        if (address.protocol() == QAbstractSocket::IPv4Protocol && address != QHostAddress(QHostAddress::LocalHost)) {
            comboBoxIP->addItem(address.toString());
        }
    }
    // 如果没有找到其他IP，添加本地回环
    if (comboBoxIP->count() == 0) {
        comboBoxIP->addItem(QHostAddress(QHostAddress::LocalHost).toString());
    }
}

void ClientWindow::on_btnConnect_clicked()
{
    if (tcpSocket->state() == QAbstractSocket::ConnectedState) {
        tcpSocket->disconnectFromHost();
        btnConnect->setEnabled(false);
    } else {
        bool ok;
        quint16 port = lineEditPort->text().toUShort(&ok);
        if (!ok || port == 0) {
            QMessageBox::warning(this, "错误", "无效的端口号!");
            return;
        }

        QString ip = comboBoxIP->currentText();
        tcpSocket->connectToHost(ip, port);
        textEditRecv->append(QString("正在连接到 %1:%2...").arg(ip).arg(port));
        btnConnect->setEnabled(false);
    }
}

void ClientWindow::onConnected()
{
    textEditRecv->append("成功连接到服务器");
    btnConnect->setText("断开");
    btnConnect->setEnabled(true);
    btnSend->setEnabled(true);
}

void ClientWindow::onDisconnected()
{
    textEditRecv->append("与服务器断开连接");
    btnConnect->setText("连接");
    btnConnect->setEnabled(true);
    btnSend->setEnabled(false);
}

void ClientWindow::onReadyRead()
{
    QByteArray data = tcpSocket->readAll();
    QString message = QString::fromUtf8(data);
    textEditRecv->append(QString("[服务器]: %1").arg(message));
}

void ClientWindow::onErrorOccurred(QAbstractSocket::SocketError error)
{
    Q_UNUSED(error)
    textEditRecv->append(QString("错误: %1").arg(tcpSocket->errorString()));
    btnConnect->setEnabled(true);
    btnConnect->setText("连接");
    btnSend->setEnabled(false);
}

void ClientWindow::on_btnSend_clicked()
{
    QString message = textEditSend->toPlainText().trimmed();
    if (message.isEmpty() || tcpSocket->state() != QAbstractSocket::ConnectedState) {
        return;
    }
    tcpSocket->write(message.toUtf8());
    textEditSend->clear();
    textEditRecv->append(QString("[客户端]: %1").arg(message));
}
