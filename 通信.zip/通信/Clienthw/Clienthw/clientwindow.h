#ifndef CLIENTWINDOW_H
#define CLIENTWINDOW_H

#include <QWidget>
#include <QTcpSocket>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QComboBox>
#include <QMessageBox>
#include <QNetworkInterface>

class ClientWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ClientWindow(QWidget *parent = nullptr);
    ~ClientWindow();

private slots:
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onErrorOccurred(QAbstractSocket::SocketError error);
    void on_btnConnect_clicked();
    void on_btnSend_clicked();

private:
    void populateIPs();

    QTcpSocket *tcpSocket;

    // UI 控件
    QVBoxLayout *mainLayout;
    QHBoxLayout *connectLayout;
    QLabel *labelIP;
    QComboBox *comboBoxIP;
    QLabel *labelPort;
    QLineEdit *lineEditPort;
    QPushButton *btnConnect;
    QTextEdit *textEditRecv;
    QTextEdit *textEditSend;
    QPushButton *btnSend;
};

#endif // CLIENTWINDOW_H
